library(ggplot2)
library(jpeg)
# Put initialization code in this file.
path_to_course <- file.path(find.package("swirl"),"Courses/Exploratory_Data_Analysis/Principles_of_Analytic_Graphs")
plot.new()