# Put initialization code in this file. The variables you create
# here will show up in the user's workspace when he or she begins
# the lesson.
