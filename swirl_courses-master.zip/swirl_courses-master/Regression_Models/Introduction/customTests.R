# So swirl does not repeat execution of plot commands
AUTO_DETECT_NEWVAR <- FALSE
