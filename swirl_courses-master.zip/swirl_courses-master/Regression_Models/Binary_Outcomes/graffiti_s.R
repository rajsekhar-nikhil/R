plot(c(3,23,29,55), c(0.5, 0.5, 1.0, 1.0), type='l', lwd=5, col="purple", col.lab="purple", ylim=c(0.25,1),
     xlab="Ravens' Score", ylab="Probability of a Ravens win", col.main="purple",
     main="Crude estimate of Ravens' win probability\nvs the points which they score.")
