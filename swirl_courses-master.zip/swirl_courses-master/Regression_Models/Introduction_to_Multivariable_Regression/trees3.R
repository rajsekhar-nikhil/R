print(lm(Volume ~ Constant - 1, eliminate("Height", trees2)))
